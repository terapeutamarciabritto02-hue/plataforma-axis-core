import type { Metadata } from 'next'
import { createServerClient } from '@/lib/supabase/server'
import { StatsCard } from '@/components/dashboard/StatsCard'
import { Users, Calendar, FileText, Activity } from 'lucide-react'

export const metadata: Metadata = { title: 'Admin' }

async function getAdminStats(supabase: Awaited<ReturnType<typeof createServerClient>>) {
  const [therapists, clients, sessions, reports] = await Promise.all([
    supabase.from('therapists').select('id', { count: 'exact', head: true }),
    supabase.from('clients').select('id', { count: 'exact', head: true }),
    supabase.from('sessions').select('id', { count: 'exact', head: true })
      .gte('created_at', new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()),
    supabase.from('reports').select('id', { count: 'exact', head: true }),
  ])
  return {
    therapists: therapists.count ?? 0,
    clients:    clients.count ?? 0,
    sessions:   sessions.count ?? 0,
    reports:    reports.count ?? 0,
  }
}

export default async function AdminPage() {
  const supabase = await createServerClient()
  const stats = await getAdminStats(supabase)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-white">Painel Admin</h1>
        <p className="text-sm text-gray-400 mt-1">Visão geral da plataforma</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="Terapeutas"
          value={stats.therapists}
          icon={<Users className="w-5 h-5" />}
          color="blue"
        />
        <StatsCard
          title="Clientes"
          value={stats.clients}
          icon={<Users className="w-5 h-5" />}
          color="green"
        />
        <StatsCard
          title="Sessões (30d)"
          value={stats.sessions}
          icon={<Calendar className="w-5 h-5" />}
          color="purple"
        />
        <StatsCard
          title="Relatórios"
          value={stats.reports}
          icon={<FileText className="w-5 h-5" />}
          color="orange"
        />
      </div>
    </div>
  )
}
