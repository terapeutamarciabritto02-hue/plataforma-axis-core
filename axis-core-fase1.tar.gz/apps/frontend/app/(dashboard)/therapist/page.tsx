import type { Metadata } from 'next'
import { createServerClient } from '@/lib/supabase/server'
import { StatsCard } from '@/components/dashboard/StatsCard'
import { Users, Calendar, FileText, Zap } from 'lucide-react'

export const metadata: Metadata = { title: 'Painel Terapeuta' }

export default async function TherapistPage() {
  const supabase = await createServerClient()
  const { data: { user } } = await supabase.auth.getUser()

  const { data: therapist } = await supabase
    .from('therapists')
    .select('id, tenant_id')
    .eq('profile_id', user!.id)
    .single()

  if (!therapist) {
    return <div className="text-red-400">Perfil de terapeuta não encontrado.</div>
  }

  const [clients, todaySessions, pendingReports, activeTables] = await Promise.all([
    supabase.from('clients')
      .select('id', { count: 'exact', head: true })
      .eq('therapist_id', therapist.id)
      .eq('is_active', true),
    supabase.from('sessions')
      .select('id', { count: 'exact', head: true })
      .eq('therapist_id', therapist.id)
      .gte('scheduled_at', new Date().toISOString().split('T')[0]),
    supabase.from('reports')
      .select('id', { count: 'exact', head: true })
      .eq('therapist_id', therapist.id)
      .eq('status', 'draft'),
    supabase.from('axis_tables')
      .select('id', { count: 'exact', head: true })
      .eq('tenant_id', therapist.tenant_id)
      .eq('is_active', true),
  ])

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-white">Meu Painel</h1>
        <p className="text-sm text-gray-400 mt-1">Resumo das suas atividades</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="Clientes Ativos"
          value={clients.count ?? 0}
          icon={<Users className="w-5 h-5" />}
          color="blue"
        />
        <StatsCard
          title="Sessões Hoje"
          value={todaySessions.count ?? 0}
          icon={<Calendar className="w-5 h-5" />}
          color="green"
        />
        <StatsCard
          title="Relatórios Pendentes"
          value={pendingReports.count ?? 0}
          icon={<FileText className="w-5 h-5" />}
          color="orange"
        />
        <StatsCard
          title="Mesas Ativas"
          value={activeTables.count ?? 0}
          icon={<Zap className="w-5 h-5" />}
          color="purple"
        />
      </div>
    </div>
  )
}
