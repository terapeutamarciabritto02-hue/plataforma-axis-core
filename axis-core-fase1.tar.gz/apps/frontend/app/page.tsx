import { redirect } from 'next/navigation'
import { createServerClient } from '@/lib/supabase/server'

export default async function RootPage() {
  const supabase = await createServerClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    redirect('/login')
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single()

  const roleRedirects: Record<string, string> = {
    admin:     '/admin',
    therapist: '/therapist',
    client:    '/client',
    student:   '/student',
  }

  redirect(roleRedirects[profile?.role ?? 'client'] ?? '/client')
}
