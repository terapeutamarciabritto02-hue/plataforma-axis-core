import { create } from 'zustand'
import { createClient } from '@/lib/supabase/client'
import type { User } from '@supabase/supabase-js'
import type { Profile, UserRole } from '@axis/core'

interface AuthState {
  user:    User | null
  profile: Profile | null
  role:    UserRole | null
  loading: boolean

  // Actions
  initialize:  () => Promise<void>
  signIn:      (email: string, password: string) => Promise<{ error: string | null }>
  signOut:     () => Promise<void>
  setProfile:  (profile: Profile) => void
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user:    null,
  profile: null,
  role:    null,
  loading: true,

  initialize: async () => {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (user) {
      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single()

      set({ user, profile, role: profile?.role ?? null, loading: false })
    } else {
      set({ user: null, profile: null, role: null, loading: false })
    }

    // Listener para mudanças de sessão
    supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' && session?.user) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .single()

        set({ user: session.user, profile, role: profile?.role ?? null })
      } else if (event === 'SIGNED_OUT') {
        set({ user: null, profile: null, role: null })
      }
    })
  },

  signIn: async (email, password) => {
    const supabase = createClient()
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    return { error: error?.message ?? null }
  },

  signOut: async () => {
    const supabase = createClient()
    await supabase.auth.signOut()
    set({ user: null, profile: null, role: null })
  },

  setProfile: (profile) => set({ profile, role: profile.role }),
}))
