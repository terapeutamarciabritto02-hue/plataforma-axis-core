type EventHandler = (data: unknown) => void

interface WSMessage {
  type: string
  session_id?: string
  timestamp: string
  payload: Record<string, unknown>
}

class WebSocketManager {
  private ws: WebSocket | null = null
  private sessionId: string | null = null
  private handlers: Map<string, Set<EventHandler>> = new Map()
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null
  private reconnectAttempts = 0
  private readonly MAX_RECONNECT = 5
  private readonly RECONNECT_DELAY = 2000

  connect(sessionId: string): void {
    if (this.ws?.readyState === WebSocket.OPEN && this.sessionId === sessionId) {
      return
    }

    this.sessionId = sessionId
    this.reconnectAttempts = 0
    this._connect()
  }

  private _connect(): void {
    const url = `${process.env.NEXT_PUBLIC_API_URL!.replace('http', 'ws')}/ws/session/${this.sessionId}`
    this.ws = new WebSocket(url)

    this.ws.onopen = () => {
      console.info(`[WS] Connected to session ${this.sessionId}`)
      this.reconnectAttempts = 0
      this._emit('connected', {})
    }

    this.ws.onmessage = (event) => {
      try {
        const msg: WSMessage = JSON.parse(event.data)
        this._emit(msg.type, msg.payload)
        this._emit('*', msg)
      } catch (err) {
        console.error('[WS] Parse error:', err)
      }
    }

    this.ws.onclose = () => {
      this._emit('disconnected', {})
      this._scheduleReconnect()
    }

    this.ws.onerror = (error) => {
      console.error('[WS] Error:', error)
      this._emit('error', { error })
    }
  }

  private _scheduleReconnect(): void {
    if (this.reconnectAttempts >= this.MAX_RECONNECT) {
      console.warn('[WS] Max reconnect attempts reached')
      return
    }
    const delay = this.RECONNECT_DELAY * Math.pow(2, this.reconnectAttempts)
    this.reconnectTimer = setTimeout(() => {
      this.reconnectAttempts++
      this._connect()
    }, delay)
  }

  on(event: string, handler: EventHandler): () => void {
    if (!this.handlers.has(event)) {
      this.handlers.set(event, new Set())
    }
    this.handlers.get(event)!.add(handler)
    // Retorna função de unsubscribe
    return () => this.handlers.get(event)?.delete(handler)
  }

  private _emit(event: string, data: unknown): void {
    this.handlers.get(event)?.forEach(handler => handler(data))
  }

  send(message: Record<string, unknown>): void {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message))
    } else {
      console.warn('[WS] Cannot send: not connected')
    }
  }

  disconnect(): void {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer)
    this.ws?.close()
    this.ws = null
    this.sessionId = null
    this.handlers.clear()
  }

  get isConnected(): boolean {
    return this.ws?.readyState === WebSocket.OPEN
  }
}

// Singleton
export const wsManager = new WebSocketManager()
