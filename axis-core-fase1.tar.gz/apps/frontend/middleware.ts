import { createServerClient } from '@supabase/ssr'
import { NextResponse, type NextRequest } from 'next/server'
import type { UserRole } from '@axis/core'

const ROUTE_PERMISSIONS: Record<string, UserRole[]> = {
  '/admin':     ['admin'],
  '/therapist': ['admin', 'therapist'],
  '/client':    ['admin', 'therapist', 'client'],
  '/student':   ['admin', 'therapist', 'client', 'student'],
}

export async function middleware(request: NextRequest) {
  let response = NextResponse.next({ request })

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll: () => request.cookies.getAll(),
        setAll: (cookiesToSet) => {
          cookiesToSet.forEach(({ name, value, options }) => {
            request.cookies.set(name, value)
            response = NextResponse.next({ request })
            response.cookies.set(name, value, options)
          })
        },
      },
    }
  )

  const { data: { user } } = await supabase.auth.getUser()

  const { pathname } = request.nextUrl

  // Rotas públicas — deixa passar
  if (pathname.startsWith('/login') || pathname.startsWith('/_next') || pathname.startsWith('/api')) {
    // Se já está logado e vai para /login, redireciona para home
    if (user && pathname === '/login') {
      return NextResponse.redirect(new URL('/', request.url))
    }
    return response
  }

  // Não autenticado
  if (!user) {
    const loginUrl = new URL('/login', request.url)
    loginUrl.searchParams.set('redirect', pathname)
    return NextResponse.redirect(loginUrl)
  }

  // Busca role do perfil
  const { data: profile } = await supabase
    .from('profiles')
    .select('role, is_active')
    .eq('id', user.id)
    .single()

  if (!profile || !profile.is_active) {
    return NextResponse.redirect(new URL('/login?error=inactive', request.url))
  }

  // Verifica permissão de rota
  const matchedPrefix = Object.keys(ROUTE_PERMISSIONS).find(prefix =>
    pathname.startsWith(prefix)
  )

  if (matchedPrefix) {
    const allowedRoles = ROUTE_PERMISSIONS[matchedPrefix]
    if (!allowedRoles.includes(profile.role as UserRole)) {
      return NextResponse.redirect(new URL('/', request.url))
    }
  }

  response.headers.set('x-user-id', user.id)
  response.headers.set('x-user-role', profile.role)
  return response
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
}
