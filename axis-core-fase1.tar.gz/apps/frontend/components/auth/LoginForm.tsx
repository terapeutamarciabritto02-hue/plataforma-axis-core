'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'

export function LoginForm() {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError(null)

    const supabase = createClient()
    const { error: authError } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (authError) {
      setError('Email ou senha incorretos.')
      setLoading(false)
      return
    }

    router.push('/')
    router.refresh()
  }

  return (
    <div className="bg-surface-50 border border-surface-100 rounded-xl p-8 space-y-6">
      {/* Logo */}
      <div className="text-center space-y-1">
        <div className="inline-flex items-center gap-2">
          <span className="text-axis-400 font-mono font-bold text-2xl tracking-tight">
            AXIS
          </span>
          <span className="text-white font-semibold text-2xl">CORE™</span>
        </div>
        <p className="text-gray-400 text-sm">Acesse sua conta</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-1">
          <label className="text-sm text-gray-300" htmlFor="email">
            Email
          </label>
          <input
            id="email"
            type="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            required
            autoComplete="email"
            className="
              w-full px-3 py-2.5 rounded-lg text-sm
              bg-surface-100 border border-surface-200
              text-white placeholder-gray-500
              focus:outline-none focus:ring-2 focus:ring-axis-500 focus:border-transparent
              transition-colors
            "
            placeholder="seu@email.com"
          />
        </div>

        <div className="space-y-1">
          <label className="text-sm text-gray-300" htmlFor="password">
            Senha
          </label>
          <input
            id="password"
            type="password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            required
            autoComplete="current-password"
            className="
              w-full px-3 py-2.5 rounded-lg text-sm
              bg-surface-100 border border-surface-200
              text-white placeholder-gray-500
              focus:outline-none focus:ring-2 focus:ring-axis-500 focus:border-transparent
              transition-colors
            "
            placeholder="••••••••"
          />
        </div>

        {error && (
          <p className="text-red-400 text-sm bg-red-400/10 rounded-lg px-3 py-2">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={loading}
          className="
            w-full py-2.5 rounded-lg text-sm font-medium
            bg-axis-600 hover:bg-axis-500 disabled:bg-axis-800
            text-white transition-colors
            focus:outline-none focus:ring-2 focus:ring-axis-500 focus:ring-offset-2 focus:ring-offset-surface-50
          "
        >
          {loading ? 'Entrando...' : 'Entrar'}
        </button>
      </form>

      <p className="text-center text-xs text-gray-500">
        Ferramenta de uso exclusivo de profissionais cadastrados.
      </p>
    </div>
  )
}
