import { cn } from '@/lib/utils'

interface StatsCardProps {
  title: string
  value: number | string
  icon: React.ReactNode
  color: 'blue' | 'green' | 'purple' | 'orange' | 'red'
  delta?: { value: string; positive: boolean }
}

const COLOR_MAP = {
  blue:   'bg-blue-500/10 text-blue-400 ring-blue-500/20',
  green:  'bg-emerald-500/10 text-emerald-400 ring-emerald-500/20',
  purple: 'bg-axis-500/10 text-axis-400 ring-axis-500/20',
  orange: 'bg-orange-500/10 text-orange-400 ring-orange-500/20',
  red:    'bg-red-500/10 text-red-400 ring-red-500/20',
}

export function StatsCard({ title, value, icon, color, delta }: StatsCardProps) {
  return (
    <div className="bg-surface-50 border border-surface-100 rounded-xl p-4 space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-400">{title}</span>
        <span className={cn('p-2 rounded-lg ring-1', COLOR_MAP[color])}>
          {icon}
        </span>
      </div>
      <div>
        <p className="text-2xl font-semibold text-white">{value}</p>
        {delta && (
          <p className={cn('text-xs mt-1', delta.positive ? 'text-emerald-400' : 'text-red-400')}>
            {delta.positive ? '↑' : '↓'} {delta.value}
          </p>
        )}
      </div>
    </div>
  )
}
