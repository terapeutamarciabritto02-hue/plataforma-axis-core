'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  LayoutDashboard, Users, Calendar, FileText,
  Zap, BookOpen, Settings, LogOut
} from 'lucide-react'
import { cn } from '@/lib/utils'
import type { UserRole } from '@axis/core'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'

interface NavItem {
  label: string
  href: string
  icon: React.ReactNode
  roles: UserRole[]
}

const NAV_ITEMS: NavItem[] = [
  // Admin
  { label: 'Admin',        href: '/admin',           icon: <LayoutDashboard className="w-4 h-4" />, roles: ['admin'] },
  { label: 'Terapeutas',   href: '/admin/therapists',icon: <Users className="w-4 h-4" />,           roles: ['admin'] },

  // Terapeuta
  { label: 'Dashboard',    href: '/therapist',        icon: <LayoutDashboard className="w-4 h-4" />, roles: ['therapist'] },
  { label: 'Clientes',     href: '/therapist/clients',icon: <Users className="w-4 h-4" />,           roles: ['therapist'] },
  { label: 'Sessões',      href: '/therapist/sessions',icon: <Calendar className="w-4 h-4" />,       roles: ['therapist'] },
  { label: 'Engine',       href: '/therapist/engine', icon: <Zap className="w-4 h-4" />,             roles: ['therapist'] },

  // Cliente
  { label: 'Meu Painel',   href: '/client',           icon: <LayoutDashboard className="w-4 h-4" />, roles: ['client'] },
  { label: 'Histórico',    href: '/client/history',   icon: <Calendar className="w-4 h-4" />,        roles: ['client'] },
  { label: 'Relatórios',   href: '/client/reports',   icon: <FileText className="w-4 h-4" />,        roles: ['client'] },

  // Aluno
  { label: 'Cursos',       href: '/student/courses',  icon: <BookOpen className="w-4 h-4" />,        roles: ['student'] },
]

interface SidebarProps {
  role: UserRole
}

export function Sidebar({ role }: SidebarProps) {
  const pathname = usePathname()
  const router = useRouter()
  const visibleItems = NAV_ITEMS.filter(item => item.roles.includes(role))

  async function handleSignOut() {
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push('/login')
  }

  return (
    <aside className="w-56 flex flex-col bg-surface-50 border-r border-surface-100 shrink-0">
      {/* Logo */}
      <div className="h-14 flex items-center px-4 border-b border-surface-100">
        <span className="text-axis-400 font-mono font-bold tracking-tight">AXIS</span>
        <span className="text-white font-semibold ml-1">CORE™</span>
      </div>

      {/* Nav */}
      <nav className="flex-1 py-3 space-y-0.5 px-2 overflow-y-auto">
        {visibleItems.map(item => (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              'flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-colors',
              pathname === item.href || pathname.startsWith(item.href + '/')
                ? 'bg-axis-900/60 text-axis-300'
                : 'text-gray-400 hover:text-white hover:bg-surface-100'
            )}
          >
            {item.icon}
            {item.label}
          </Link>
        ))}
      </nav>

      {/* Footer */}
      <div className="p-2 border-t border-surface-100 space-y-0.5">
        <Link
          href="/settings"
          className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm text-gray-400 hover:text-white hover:bg-surface-100 transition-colors"
        >
          <Settings className="w-4 h-4" />
          Configurações
        </Link>
        <button
          onClick={handleSignOut}
          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm text-gray-400 hover:text-red-400 hover:bg-red-400/10 transition-colors"
        >
          <LogOut className="w-4 h-4" />
          Sair
        </button>
      </div>
    </aside>
  )
}
