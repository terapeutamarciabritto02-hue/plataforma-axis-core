'use client'

import { useEffect, useRef, useCallback } from 'react'
import { wsManager } from '@/lib/websocket/client'

interface UseWebSocketOptions {
  sessionId: string | null
  onMessage?: (type: string, payload: unknown) => void
  onConnect?: () => void
  onDisconnect?: () => void
}

export function useWebSocket({
  sessionId,
  onMessage,
  onConnect,
  onDisconnect,
}: UseWebSocketOptions) {
  const cleanupRef = useRef<Array<() => void>>([])

  useEffect(() => {
    if (!sessionId) return

    wsManager.connect(sessionId)

    const unsubscribers: Array<() => void> = []

    if (onConnect) {
      unsubscribers.push(wsManager.on('connected', onConnect))
    }
    if (onDisconnect) {
      unsubscribers.push(wsManager.on('disconnected', onDisconnect))
    }
    if (onMessage) {
      unsubscribers.push(wsManager.on('*', (data) => {
        const msg = data as { type: string; payload: unknown }
        onMessage(msg.type, msg.payload)
      }))
    }

    cleanupRef.current = unsubscribers

    return () => {
      unsubscribers.forEach(unsub => unsub())
    }
  }, [sessionId])

  const send = useCallback((message: Record<string, unknown>) => {
    wsManager.send(message)
  }, [])

  const subscribe = useCallback((event: string, handler: (data: unknown) => void) => {
    return wsManager.on(event, handler)
  }, [])

  return { send, subscribe, isConnected: wsManager.isConnected }
}
