from fastapi import APIRouter, Depends
from app.dependencies import get_current_user, CurrentUser

router = APIRouter()


@router.get("/", summary="Listar relatórios")
async def list_reports(current_user: CurrentUser = Depends(get_current_user)):
    # Implementação completa na Fase 2 (geração PDF)
    return {"reports": [], "total": 0}
