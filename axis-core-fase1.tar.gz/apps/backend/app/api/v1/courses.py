from fastapi import APIRouter, Depends
from supabase import AsyncClient
from app.dependencies import get_current_user, get_supabase, CurrentUser

router = APIRouter()


@router.get("/", summary="Listar cursos disponíveis")
async def list_courses(
    current_user: CurrentUser = Depends(get_current_user),
    supabase: AsyncClient     = Depends(get_supabase),
):
    result = await supabase.table("courses") \
        .select("id, title, description, thumbnail_url, is_public, price_brl") \
        .eq("is_published", True) \
        .execute()
    return {"courses": result.data, "total": len(result.data)}
