from fastapi import APIRouter, Depends, HTTPException
from supabase import AsyncClient
from app.dependencies import get_current_user, get_supabase, CurrentUser
from app.core.permissions import UserRole

router = APIRouter()


@router.get("/", summary="Listar terapeutas (admin)")
async def list_therapists(
    current_user: CurrentUser = Depends(get_current_user),
    supabase: AsyncClient     = Depends(get_supabase),
):
    if current_user.role != UserRole.ADMIN:
        raise HTTPException(status_code=403, detail="Admin only")

    result = await supabase.table("therapists") \
        .select("*, profiles(*)") \
        .execute()
    return {"therapists": result.data, "total": len(result.data)}


@router.get("/me", summary="Perfil do terapeuta logado")
async def get_my_therapist_profile(
    current_user: CurrentUser = Depends(get_current_user),
    supabase: AsyncClient     = Depends(get_supabase),
):
    if current_user.role != UserRole.THERAPIST:
        raise HTTPException(status_code=403, detail="Therapists only")

    result = await supabase.table("therapists") \
        .select("*") \
        .eq("profile_id", current_user.id) \
        .single() \
        .execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Therapist profile not found")
    return result.data
