from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, Request
from supabase import AsyncClient

from app.dependencies import get_current_user, get_supabase, CurrentUser
from app.schemas.engine import (
    TableListResponse, TableDefinitionResponse,
    EngineCommandRequest, EngineCommandResponse,
    EngineStatusResponse,
)
from app.core.permissions import UserRole

router = APIRouter()


@router.get(
    "/tables",
    response_model=TableListResponse,
    summary="Listar mesas do tenant",
)
async def list_tables(
    current_user: CurrentUser = Depends(get_current_user),
    supabase: AsyncClient     = Depends(get_supabase),
):
    query = supabase.table("axis_tables").select("*").eq("is_active", True)

    if current_user.role != UserRole.ADMIN and current_user.tenant_id:
        query = query.eq("tenant_id", str(current_user.tenant_id))

    result = await query.execute()
    return TableListResponse(tables=result.data, total=len(result.data))


@router.get(
    "/tables/{table_id}",
    response_model=TableDefinitionResponse,
    summary="Definição de uma mesa",
)
async def get_table(
    table_id: UUID,
    current_user: CurrentUser = Depends(get_current_user),
    supabase: AsyncClient     = Depends(get_supabase),
):
    result = await supabase.table("axis_tables") \
        .select("*") \
        .eq("id", str(table_id)) \
        .maybeSingle() \
        .execute()

    if not result.data:
        raise HTTPException(status_code=404, detail="Table not found")

    return result.data


@router.post(
    "/command",
    response_model=EngineCommandResponse,
    summary="Enviar comando MQTT para uma mesa",
)
async def send_command(
    body: EngineCommandRequest,
    request: Request,
    current_user: CurrentUser = Depends(get_current_user),
):
    if current_user.role not in (UserRole.ADMIN, UserRole.THERAPIST):
        raise HTTPException(status_code=403, detail="Permission denied: engine:control")

    mqtt = request.app.state.mqtt_client
    topic = f"axis/{body.table_slug}/{body.command}"

    payload = {**body.payload}
    if body.session_id:
        payload["session_id"] = str(body.session_id)

    success = await mqtt.publish(topic, payload)

    return EngineCommandResponse(
        success=success,
        topic=topic,
        command=body.command,
        message=f"Command '{body.command}' dispatched to '{body.table_slug}'"
        if success else "MQTT not connected — command logged only",
    )


@router.get(
    "/status/{table_id}",
    response_model=EngineStatusResponse,
    summary="Status de dispositivo físico",
)
async def get_table_status(
    table_id: UUID,
    current_user: CurrentUser = Depends(get_current_user),
    supabase: AsyncClient     = Depends(get_supabase),
):
    result = await supabase.table("axis_tables") \
        .select("id, name, device_id, device_status, updated_at") \
        .eq("id", str(table_id)) \
        .maybeSingle() \
        .execute()

    if not result.data:
        raise HTTPException(status_code=404, detail="Table not found")

    return result.data


@router.get(
    "/ws-stats",
    summary="Estatísticas de conexões WebSocket ativas",
)
async def ws_stats(
    request: Request,
    current_user: CurrentUser = Depends(get_current_user),
):
    if current_user.role != UserRole.ADMIN:
        raise HTTPException(status_code=403, detail="Admin only")

    ws_manager = request.app.state.ws_manager
    return {
        "active_sessions":  ws_manager.active_sessions(),
        "total_connections": ws_manager.total_connections(),
    }
