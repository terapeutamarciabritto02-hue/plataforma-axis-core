from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, Request, Query
from supabase import AsyncClient

from app.dependencies import get_current_user, get_supabase, CurrentUser
from app.schemas.telemetry import (
    TelemetryWrite, TelemetryResponse, TelemetryListResponse,
    BiometryWrite, BiometryResponse,
)
from app.core.permissions import UserRole
from datetime import datetime, timezone

router = APIRouter()


@router.post(
    "/",
    response_model=TelemetryResponse,
    status_code=201,
    summary="Registrar dado telemétrico",
)
async def write_telemetry(
    body: TelemetryWrite,
    request: Request,
    current_user: CurrentUser = Depends(get_current_user),
    supabase: AsyncClient     = Depends(get_supabase),
):
    if current_user.role not in (UserRole.ADMIN, UserRole.THERAPIST):
        raise HTTPException(status_code=403, detail="Permission denied: telemetry:write")

    row = {
        "session_id": str(body.session_id),
        "tenant_id":  str(current_user.tenant_id),
        "source":     body.source,
        "payload":    body.payload,
        "timestamp":  datetime.now(timezone.utc).isoformat(),
    }

    result = await supabase.table("telemetry_logs").insert(row).execute()

    # Broadcast via WebSocket se sessão ativa
    ws_manager = request.app.state.ws_manager
    await ws_manager.broadcast(str(body.session_id), "telemetry.update", body.payload)

    return TelemetryResponse(**result.data[0])


@router.get(
    "/{session_id}",
    response_model=TelemetryListResponse,
    summary="Histórico de telemetria de uma sessão",
)
async def get_telemetry(
    session_id: UUID,
    limit: int = Query(100, ge=1, le=1000),
    current_user: CurrentUser = Depends(get_current_user),
    supabase: AsyncClient     = Depends(get_supabase),
):
    if current_user.role not in (UserRole.ADMIN, UserRole.THERAPIST):
        raise HTTPException(status_code=403, detail="Permission denied")

    result = await supabase.table("telemetry_logs") \
        .select("*", count="exact") \
        .eq("session_id", str(session_id)) \
        .order("timestamp", desc=True) \
        .limit(limit) \
        .execute()

    return TelemetryListResponse(
        logs=[TelemetryResponse(**r) for r in result.data],
        total=result.count or 0,
    )


@router.post(
    "/biometry",
    response_model=BiometryResponse,
    status_code=201,
    summary="Registrar leitura biométrica mensurável",
)
async def write_biometry(
    body: BiometryWrite,
    current_user: CurrentUser = Depends(get_current_user),
    supabase: AsyncClient     = Depends(get_supabase),
):
    if current_user.role not in (UserRole.ADMIN, UserRole.THERAPIST):
        raise HTTPException(status_code=403, detail="Permission denied")

    row = {
        "session_id":    str(body.session_id),
        "tenant_id":     str(current_user.tenant_id),
        "metric_type":   body.metric_type,
        "value":         body.value,
        "unit":          body.unit,
        "device_source": body.device_source,
        "raw_data":      body.raw_data,
        "timestamp":     datetime.now(timezone.utc).isoformat(),
    }

    result = await supabase.table("biometry_logs").insert(row).execute()
    return BiometryResponse(**result.data[0])
