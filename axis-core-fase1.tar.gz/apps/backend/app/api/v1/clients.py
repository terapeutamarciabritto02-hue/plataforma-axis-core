from uuid import UUID
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from supabase import AsyncClient

from app.dependencies import get_current_user, get_supabase, CurrentUser
from app.schemas.user import ClientCreate, ClientUpdate, ClientResponse, ClientListResponse
from app.core.permissions import UserRole

router = APIRouter()


async def _get_therapist_id(supabase: AsyncClient, profile_id: str) -> str:
    r = await supabase.table("therapists") \
        .select("id") \
        .eq("profile_id", profile_id) \
        .single() \
        .execute()
    if not r.data:
        raise HTTPException(status_code=403, detail="Therapist profile not found")
    return r.data["id"]


@router.post(
    "/",
    response_model=ClientResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Criar cliente",
)
async def create_client(
    body: ClientCreate,
    current_user: CurrentUser = Depends(get_current_user),
    supabase: AsyncClient     = Depends(get_supabase),
):
    if current_user.role not in (UserRole.ADMIN, UserRole.THERAPIST):
        raise HTTPException(status_code=403, detail="Permission denied")

    therapist_id = await _get_therapist_id(supabase, current_user.id)

    row = {
        "tenant_id":    str(current_user.tenant_id),
        "therapist_id": therapist_id,
        **body.model_dump(exclude_none=True),
    }

    result = await supabase.table("clients").insert(row).execute()
    return ClientResponse(**result.data[0])


@router.get(
    "/",
    response_model=ClientListResponse,
    summary="Listar clientes",
)
async def list_clients(
    search:    Optional[str] = Query(None),
    active:    bool          = Query(True),
    page:      int           = Query(1, ge=1),
    page_size: int           = Query(20, ge=1, le=100),
    current_user: CurrentUser = Depends(get_current_user),
    supabase: AsyncClient     = Depends(get_supabase),
):
    if current_user.role not in (UserRole.ADMIN, UserRole.THERAPIST):
        raise HTTPException(status_code=403, detail="Permission denied")

    query = supabase.table("clients").select("*", count="exact") \
        .eq("is_active", active)

    if current_user.role == UserRole.THERAPIST:
        therapist_id = await _get_therapist_id(supabase, current_user.id)
        query = query.eq("therapist_id", therapist_id)

    if search:
        query = query.ilike("full_name", f"%{search}%")

    offset = (page - 1) * page_size
    result = await query.range(offset, offset + page_size - 1) \
        .order("created_at", desc=True) \
        .execute()

    return ClientListResponse(
        clients=[ClientResponse(**c) for c in result.data],
        total=result.count or 0,
        page=page,
        page_size=page_size,
    )


@router.get("/{client_id}", response_model=ClientResponse, summary="Buscar cliente")
async def get_client(
    client_id: UUID,
    current_user: CurrentUser = Depends(get_current_user),
    supabase: AsyncClient     = Depends(get_supabase),
):
    result = await supabase.table("clients") \
        .select("*") \
        .eq("id", str(client_id)) \
        .maybeSingle() \
        .execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Client not found")
    return result.data


@router.patch("/{client_id}", response_model=ClientResponse, summary="Atualizar cliente")
async def update_client(
    client_id: UUID,
    body: ClientUpdate,
    current_user: CurrentUser = Depends(get_current_user),
    supabase: AsyncClient     = Depends(get_supabase),
):
    if current_user.role not in (UserRole.ADMIN, UserRole.THERAPIST):
        raise HTTPException(status_code=403, detail="Permission denied")

    updates = body.model_dump(exclude_none=True)
    result = await supabase.table("clients") \
        .update(updates) \
        .eq("id", str(client_id)) \
        .execute()
    return result.data[0]


@router.delete(
    "/{client_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Desativar cliente",
)
async def deactivate_client(
    client_id: UUID,
    current_user: CurrentUser = Depends(get_current_user),
    supabase: AsyncClient     = Depends(get_supabase),
):
    if current_user.role not in (UserRole.ADMIN,):
        raise HTTPException(status_code=403, detail="Admin only")
    await supabase.table("clients") \
        .update({"is_active": False}) \
        .eq("id", str(client_id)) \
        .execute()
