from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, EmailStr
from supabase import AsyncClient

from app.db.supabase import get_db
from app.dependencies import get_current_user, CurrentUser

router = APIRouter()


class SignUpRequest(BaseModel):
    email: EmailStr
    password: str
    full_name: str
    role: str = "client"


class SignInRequest(BaseModel):
    email: EmailStr
    password: str


class AuthResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user_id: str
    role: str


@router.post(
    "/signup",
    status_code=status.HTTP_201_CREATED,
    summary="Registrar novo usuário",
)
async def signup(
    body: SignUpRequest,
    supabase: AsyncClient = Depends(get_db),
):
    valid_roles = {"client", "therapist", "student"}
    if body.role not in valid_roles:
        raise HTTPException(status_code=400, detail=f"Invalid role: {body.role}")

    result = await supabase.auth.sign_up({
        "email":    body.email,
        "password": body.password,
        "options": {
            "data": {
                "full_name": body.full_name,
                "role":      body.role,
            }
        },
    })

    if result.user is None:
        raise HTTPException(status_code=400, detail="Signup failed")

    return {
        "message": "Account created. Check your email to confirm.",
        "user_id": result.user.id,
    }


@router.post(
    "/signin",
    response_model=AuthResponse,
    summary="Login",
)
async def signin(
    body: SignInRequest,
    supabase: AsyncClient = Depends(get_db),
):
    result = await supabase.auth.sign_in_with_password({
        "email":    body.email,
        "password": body.password,
    })

    if not result.session:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
        )

    # Busca role
    profile = await supabase.table("profiles") \
        .select("role") \
        .eq("id", result.user.id) \
        .single() \
        .execute()

    return AuthResponse(
        access_token=result.session.access_token,
        user_id=result.user.id,
        role=profile.data["role"] if profile.data else "client",
    )


@router.post("/signout", summary="Logout")
async def signout(
    current_user: CurrentUser = Depends(get_current_user),
    supabase: AsyncClient = Depends(get_db),
):
    await supabase.auth.sign_out()
    return {"message": "Signed out"}


@router.get("/me", summary="Perfil do usuário autenticado")
async def me(current_user: CurrentUser = Depends(get_current_user)):
    return {
        "id":        current_user.id,
        "role":      current_user.role,
        "tenant_id": current_user.tenant_id,
    }
