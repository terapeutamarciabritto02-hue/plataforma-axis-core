from uuid import UUID
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from supabase import AsyncClient

from app.dependencies import get_current_user, get_supabase, CurrentUser
from app.schemas.session import (
    SessionCreate, SessionUpdate,
    SessionResponse, SessionListResponse, SessionStartResponse,
)
from app.services.session_service import SessionService
from app.core.permissions import UserRole

router = APIRouter()


@router.post(
    "/",
    response_model=SessionResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Criar sessão",
)
async def create_session(
    body: SessionCreate,
    current_user: CurrentUser = Depends(get_current_user),
    supabase: AsyncClient = Depends(get_supabase),
):
    if current_user.role not in (UserRole.ADMIN, UserRole.THERAPIST):
        raise HTTPException(status_code=403, detail="Permission denied")
    return await SessionService(supabase, current_user).create(body)


@router.get(
    "/",
    response_model=SessionListResponse,
    summary="Listar sessões",
)
async def list_sessions(
    client_id:  Optional[UUID] = Query(None),
    status_:    Optional[str]  = Query(None, alias="status"),
    page:       int            = Query(1, ge=1),
    page_size:  int            = Query(20, ge=1, le=100),
    current_user: CurrentUser  = Depends(get_current_user),
    supabase: AsyncClient      = Depends(get_supabase),
):
    return await SessionService(supabase, current_user).list(
        client_id=client_id,
        status=status_,
        page=page,
        page_size=page_size,
    )


@router.get(
    "/{session_id}",
    response_model=SessionResponse,
    summary="Buscar sessão",
)
async def get_session(
    session_id: UUID,
    current_user: CurrentUser = Depends(get_current_user),
    supabase: AsyncClient     = Depends(get_supabase),
):
    session = await SessionService(supabase, current_user).get_by_id(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return session


@router.patch(
    "/{session_id}",
    response_model=SessionResponse,
    summary="Atualizar sessão",
)
async def update_session(
    session_id: UUID,
    body: SessionUpdate,
    current_user: CurrentUser = Depends(get_current_user),
    supabase: AsyncClient     = Depends(get_supabase),
):
    return await SessionService(supabase, current_user).update(session_id, body)


@router.post(
    "/{session_id}/start",
    response_model=SessionStartResponse,
    summary="Iniciar sessão",
)
async def start_session(
    session_id: UUID,
    current_user: CurrentUser = Depends(get_current_user),
    supabase: AsyncClient     = Depends(get_supabase),
):
    if current_user.role not in (UserRole.ADMIN, UserRole.THERAPIST):
        raise HTTPException(status_code=403, detail="Only therapists can start sessions")
    return await SessionService(supabase, current_user).start(session_id)


@router.post(
    "/{session_id}/end",
    response_model=SessionResponse,
    summary="Encerrar sessão",
)
async def end_session(
    session_id: UUID,
    current_user: CurrentUser = Depends(get_current_user),
    supabase: AsyncClient     = Depends(get_supabase),
):
    return await SessionService(supabase, current_user).end(session_id)


@router.delete(
    "/{session_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Cancelar sessão",
)
async def cancel_session(
    session_id: UUID,
    current_user: CurrentUser = Depends(get_current_user),
    supabase: AsyncClient     = Depends(get_supabase),
):
    if current_user.role not in (UserRole.ADMIN, UserRole.THERAPIST):
        raise HTTPException(status_code=403, detail="Permission denied")
    await SessionService(supabase, current_user).cancel(session_id)
