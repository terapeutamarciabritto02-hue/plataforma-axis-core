"""users.py"""
from fastapi import APIRouter, Depends, HTTPException
from supabase import AsyncClient
from app.dependencies import get_current_user, get_supabase, CurrentUser
from app.schemas.user import ProfileResponse, ProfileUpdate
from app.core.permissions import UserRole

router = APIRouter()


@router.get("/me", response_model=ProfileResponse, summary="Perfil próprio")
async def get_me(
    current_user: CurrentUser = Depends(get_current_user),
    supabase: AsyncClient     = Depends(get_supabase),
):
    result = await supabase.table("profiles") \
        .select("*") \
        .eq("id", current_user.id) \
        .single() \
        .execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Profile not found")
    return result.data


@router.patch("/me", response_model=ProfileResponse, summary="Atualizar perfil próprio")
async def update_me(
    body: ProfileUpdate,
    current_user: CurrentUser = Depends(get_current_user),
    supabase: AsyncClient     = Depends(get_supabase),
):
    updates = body.model_dump(exclude_none=True)
    result = await supabase.table("profiles") \
        .update(updates) \
        .eq("id", current_user.id) \
        .execute()
    return result.data[0]
