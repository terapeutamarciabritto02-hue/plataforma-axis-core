from fastapi import APIRouter

from app.api.v1 import (
    auth,
    users,
    clients,
    therapists,
    sessions,
    reports,
    telemetry,
    engine,
    courses,
)
from app.websocket.handlers import router as ws_router

api_router = APIRouter()

# REST v1
api_router.include_router(auth.router,       prefix="/v1/auth",       tags=["Auth"])
api_router.include_router(users.router,      prefix="/v1/users",      tags=["Users"])
api_router.include_router(clients.router,    prefix="/v1/clients",    tags=["Clients"])
api_router.include_router(therapists.router, prefix="/v1/therapists", tags=["Therapists"])
api_router.include_router(sessions.router,   prefix="/v1/sessions",   tags=["Sessions"])
api_router.include_router(reports.router,    prefix="/v1/reports",    tags=["Reports"])
api_router.include_router(telemetry.router,  prefix="/v1/telemetry",  tags=["Telemetry"])
api_router.include_router(engine.router,     prefix="/v1/engine",     tags=["Engine"])
api_router.include_router(courses.router,    prefix="/v1/courses",    tags=["Courses"])

# WebSocket (sem prefixo /api para URL limpa)
api_router.include_router(ws_router)
