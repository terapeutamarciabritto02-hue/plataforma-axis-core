from enum import Enum
from functools import wraps
from typing import Callable, Sequence
from fastapi import HTTPException, status


class UserRole(str, Enum):
    ADMIN     = "admin"
    THERAPIST = "therapist"
    CLIENT    = "client"
    STUDENT   = "student"


PERMISSIONS: dict[str, list[UserRole]] = {
    # Sessions
    "session:create":       [UserRole.ADMIN, UserRole.THERAPIST],
    "session:read_all":     [UserRole.ADMIN, UserRole.THERAPIST],
    "session:read_own":     [UserRole.CLIENT],
    "session:update":       [UserRole.ADMIN, UserRole.THERAPIST],
    "session:delete":       [UserRole.ADMIN],
    "session:start":        [UserRole.ADMIN, UserRole.THERAPIST],

    # Clients
    "client:create":        [UserRole.ADMIN, UserRole.THERAPIST],
    "client:read":          [UserRole.ADMIN, UserRole.THERAPIST],
    "client:update":        [UserRole.ADMIN, UserRole.THERAPIST],
    "client:delete":        [UserRole.ADMIN],

    # Reports
    "report:create":        [UserRole.ADMIN, UserRole.THERAPIST],
    "report:read_own":      [UserRole.CLIENT],
    "report:sign":          [UserRole.THERAPIST],
    "report:delete":        [UserRole.ADMIN],

    # Engine
    "engine:control":       [UserRole.ADMIN, UserRole.THERAPIST],
    "engine:read":          [UserRole.ADMIN, UserRole.THERAPIST],

    # Telemetry
    "telemetry:write":      [UserRole.ADMIN, UserRole.THERAPIST],
    "telemetry:read":       [UserRole.ADMIN, UserRole.THERAPIST],

    # Courses
    "course:manage":        [UserRole.ADMIN, UserRole.THERAPIST],
    "course:enroll":        [UserRole.STUDENT, UserRole.CLIENT],

    # Therapists
    "therapist:manage":     [UserRole.ADMIN],
    "therapist:read":       [UserRole.ADMIN],

    # Admin
    "admin:full":           [UserRole.ADMIN],
}


def check_permission(user_role: UserRole, permission: str) -> bool:
    allowed = PERMISSIONS.get(permission, [])
    return user_role in allowed


def require_permission(permission: str):
    """Decorator FastAPI para checar permissão."""
    def decorator(func: Callable):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            current_user = kwargs.get("current_user")
            if not current_user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Not authenticated",
                )
            if not check_permission(current_user.role, permission):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Permission denied: requires '{permission}'",
                )
            return await func(*args, **kwargs)
        return wrapper
    return decorator


def require_roles(roles: Sequence[UserRole]):
    """Decorator para checar roles diretamente."""
    def decorator(func: Callable):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            current_user = kwargs.get("current_user")
            if not current_user or current_user.role not in roles:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Requires one of: {[r.value for r in roles]}",
                )
            return await func(*args, **kwargs)
        return wrapper
    return decorator
