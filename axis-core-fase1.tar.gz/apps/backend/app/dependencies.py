from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import jwt, JWTError
from supabase import AsyncClient

from app.config import settings
from app.db.supabase import get_db
from app.core.permissions import UserRole

security = HTTPBearer()


class CurrentUser:
    def __init__(
        self,
        id: str,
        role: UserRole,
        tenant_id: str | None,
        is_active: bool,
    ):
        self.id = id
        self.role = role
        self.tenant_id = tenant_id
        self.is_active = is_active


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    supabase: AsyncClient = Depends(get_db),
) -> CurrentUser:
    token = credentials.credentials

    try:
        # Supabase JWT usa o JWT secret do projeto
        payload = jwt.decode(
            token,
            settings.SUPABASE_SERVICE_ROLE_KEY,
            algorithms=["HS256"],
            options={"verify_aud": False},
        )
        user_id: str = payload.get("sub")
        if not user_id:
            raise HTTPException(status_code=401, detail="Invalid token")
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
        )

    # Busca perfil no banco
    result = await supabase.table("profiles") \
        .select("id, role, is_active") \
        .eq("id", user_id) \
        .single() \
        .execute()

    if not result.data:
        raise HTTPException(status_code=401, detail="User profile not found")

    profile = result.data

    if not profile["is_active"]:
        raise HTTPException(status_code=403, detail="Account inactive")

    # Busca tenant_id se for terapeuta
    tenant_id = None
    if profile["role"] in ("therapist", "admin"):
        tenant_result = await supabase.table("tenants") \
            .select("id") \
            .eq("owner_id", user_id) \
            .maybeSingle() \
            .execute()
        if tenant_result.data:
            tenant_id = tenant_result.data["id"]

    return CurrentUser(
        id=user_id,
        role=UserRole(profile["role"]),
        tenant_id=tenant_id,
        is_active=profile["is_active"],
    )


async def get_supabase() -> AsyncClient:
    return await get_db()
