from supabase import AsyncClient, acreate_client
from app.config import settings
from functools import lru_cache


async def get_supabase_client() -> AsyncClient:
    """Cria cliente Supabase com service role (acesso total para o backend)."""
    return await acreate_client(
        settings.SUPABASE_URL,
        settings.SUPABASE_SERVICE_ROLE_KEY,
    )


# Instância singleton para reuso
_client: AsyncClient | None = None


async def get_db() -> AsyncClient:
    global _client
    if _client is None:
        _client = await get_supabase_client()
    return _client
