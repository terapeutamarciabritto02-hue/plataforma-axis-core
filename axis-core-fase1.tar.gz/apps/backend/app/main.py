from contextlib import asynccontextmanager
import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse

from app.config import settings
from app.api.router import api_router
from app.websocket.manager import ConnectionManager
from app.mqtt.client import MQTTClient

logger = logging.getLogger("axis_core")

ws_manager = ConnectionManager()
mqtt_client = MQTTClient()


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("AXIS CORE™ — starting up")
    await mqtt_client.connect()
    app.state.ws_manager = ws_manager
    app.state.mqtt_client = mqtt_client
    yield
    logger.info("AXIS CORE™ — shutting down")
    await mqtt_client.disconnect()


app = FastAPI(
    title="AXIS CORE™ API",
    version="1.0.0",
    description="Plataforma terapêutica multidimensional — API v1",
    docs_url="/docs" if not settings.is_production else None,
    redoc_url=None,
    lifespan=lifespan,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Trusted Hosts em produção
if settings.is_production:
    app.add_middleware(
        TrustedHostMiddleware,
        allowed_hosts=settings.ALLOWED_HOSTS
    )

# Rotas
app.include_router(api_router, prefix="/api")


@app.get("/health", tags=["Health"])
async def health():
    return JSONResponse({"status": "ok", "version": "1.0.0"})
