from pydantic import BaseModel, EmailStr, Field
from datetime import datetime
from uuid import UUID
from app.core.permissions import UserRole


class ProfileResponse(BaseModel):
    id: UUID
    role: UserRole
    full_name: str
    avatar_url: str | None
    phone: str | None
    is_active: bool
    created_at: datetime
    updated_at: datetime


class ProfileUpdate(BaseModel):
    full_name: str | None = Field(None, min_length=2, max_length=120)
    phone: str | None = Field(None, max_length=20)
    avatar_url: str | None = None


class TherapistResponse(BaseModel):
    id: UUID
    profile_id: UUID
    tenant_id: UUID
    bio: str | None
    specialties: list[str]
    registration_id: str | None
    profile: ProfileResponse | None = None
    created_at: datetime


class ClientCreate(BaseModel):
    full_name: str = Field(..., min_length=2, max_length=120)
    email: EmailStr | None = None
    phone: str | None = Field(None, max_length=20)
    birth_date: str | None = None        # ISO date string
    notes: str | None = None


class ClientUpdate(BaseModel):
    full_name: str | None = Field(None, min_length=2, max_length=120)
    email: EmailStr | None = None
    phone: str | None = None
    birth_date: str | None = None
    notes: str | None = None
    is_active: bool | None = None


class ClientResponse(BaseModel):
    id: UUID
    profile_id: UUID | None
    tenant_id: UUID
    therapist_id: UUID
    full_name: str
    email: str | None
    phone: str | None
    birth_date: str | None
    notes: str | None
    is_active: bool
    created_at: datetime


class ClientListResponse(BaseModel):
    clients: list[ClientResponse]
    total: int
    page: int
    page_size: int
