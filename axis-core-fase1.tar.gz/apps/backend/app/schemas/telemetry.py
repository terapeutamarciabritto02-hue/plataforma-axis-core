from pydantic import BaseModel, Field
from uuid import UUID
from datetime import datetime
from typing import Any, Literal


class TelemetryWrite(BaseModel):
    session_id: UUID
    source: Literal["websocket", "mqtt", "manual"] = "manual"
    payload: dict[str, Any] = Field(..., min_length=1)


class TelemetryResponse(BaseModel):
    id: UUID
    session_id: UUID
    tenant_id: UUID
    timestamp: datetime
    source: str
    payload: dict[str, Any]
    processed: bool


class TelemetryListResponse(BaseModel):
    logs: list[TelemetryResponse]
    total: int


class BiometryWrite(BaseModel):
    session_id: UUID
    metric_type: Literal["hrv_rmssd", "bpm", "stress_index"]
    value: float
    unit: str
    device_source: str | None = None
    raw_data: dict[str, Any] = {}


class BiometryResponse(BaseModel):
    id: UUID
    session_id: UUID
    timestamp: datetime
    metric_type: str
    value: float
    unit: str
    device_source: str | None
