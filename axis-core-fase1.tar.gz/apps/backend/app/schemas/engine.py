from pydantic import BaseModel, Field
from uuid import UUID
from typing import Any
from datetime import datetime


class TableParameterSchema(BaseModel):
    id: str
    label: str
    type: str
    unit: str | None = None
    min: float | None = None
    max: float | None = None
    default: Any
    options: list[str] | None = None
    description: str | None = None


class TableStepSchema(BaseModel):
    id: str
    order: int
    label: str
    duration_seconds: int | None = None
    parameters: dict[str, Any] = {}


class MQTTTopicsSchema(BaseModel):
    start: str
    stop: str
    status: str
    data: str


class TableCapabilitiesSchema(BaseModel):
    realtime: bool
    physical_device: bool
    biometry_input: bool
    multi_user: bool


class TableDefinitionResponse(BaseModel):
    id: UUID
    tenant_id: UUID
    name: str
    slug: str
    table_type: str
    config: dict[str, Any]
    device_id: str | None
    device_status: str
    is_active: bool
    created_at: datetime


class TableListResponse(BaseModel):
    tables: list[TableDefinitionResponse]
    total: int


class EngineCommandRequest(BaseModel):
    table_slug: str = Field(..., min_length=1, max_length=80)
    command: str = Field(..., pattern="^(start|stop|pause|update_params)$")
    payload: dict[str, Any] = {}
    session_id: UUID | None = None


class EngineCommandResponse(BaseModel):
    success: bool
    topic: str
    command: str
    message: str


class EngineStatusResponse(BaseModel):
    id: UUID
    name: str
    device_id: str | None
    device_status: str
    updated_at: datetime
