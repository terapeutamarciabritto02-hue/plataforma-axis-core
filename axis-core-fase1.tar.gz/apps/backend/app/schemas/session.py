from pydantic import BaseModel, Field
from datetime import datetime
from uuid import UUID
from typing import Any


class SessionCreate(BaseModel):
    client_id: UUID
    table_id: UUID | None = None
    protocol_id: UUID | None = None
    scheduled_at: datetime
    notes: str | None = None


class SessionUpdate(BaseModel):
    table_id: UUID | None = None
    protocol_id: UUID | None = None
    scheduled_at: datetime | None = None
    notes: str | None = None
    status: str | None = None


class SessionResponse(BaseModel):
    id: UUID
    tenant_id: UUID
    therapist_id: UUID
    client_id: UUID
    table_id: UUID | None
    protocol_id: UUID | None
    status: str
    scheduled_at: datetime
    started_at: datetime | None
    ended_at: datetime | None
    duration_min: int | None
    notes: str | None
    metadata: dict[str, Any]
    created_at: datetime
    updated_at: datetime


class SessionStartResponse(BaseModel):
    session_id: UUID
    status: str
    started_at: datetime
    websocket_url: str


class SessionListResponse(BaseModel):
    sessions: list[SessionResponse]
    total: int
    page: int
    page_size: int
