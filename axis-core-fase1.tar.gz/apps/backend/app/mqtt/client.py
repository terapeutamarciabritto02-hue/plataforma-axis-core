import asyncio
import json
import logging
from typing import Callable, Dict
from app.config import settings

logger = logging.getLogger("axis_core.mqtt")


class MQTTClient:
    """
    Cliente MQTT assíncrono para comunicação com dispositivos físicos (ESP32).
    Usa aiomqtt (wrapper do paho-mqtt).

    Tópicos padrão AXIS:
      axis/{table_slug}/start
      axis/{table_slug}/stop
      axis/{table_slug}/status
      axis/{table_slug}/data
    """

    def __init__(self):
        self._client = None
        self._handlers: Dict[str, list[Callable]] = {}
        self._connected = False
        self._listen_task: asyncio.Task | None = None

    async def connect(self) -> None:
        try:
            import aiomqtt
            self._client = aiomqtt.Client(
                hostname=settings.MQTT_BROKER_URL,
                port=settings.MQTT_PORT,
                username=settings.MQTT_USERNAME,
                password=settings.MQTT_PASSWORD if settings.MQTT_PASSWORD else None,
            )
            self._connected = True
            logger.info(
                f"[MQTT] Connected to {settings.MQTT_BROKER_URL}:{settings.MQTT_PORT}"
            )
        except Exception as e:
            logger.warning(f"[MQTT] Connection failed (non-critical): {e}")
            self._connected = False

    async def disconnect(self) -> None:
        if self._listen_task:
            self._listen_task.cancel()
        self._connected = False
        logger.info("[MQTT] Disconnected")

    async def publish(self, topic: str, payload: dict) -> bool:
        """Publica mensagem JSON em um tópico MQTT."""
        if not self._connected or not self._client:
            logger.warning(f"[MQTT] Cannot publish to {topic}: not connected")
            return False
        try:
            async with self._client as client:
                await client.publish(
                    topic,
                    json.dumps(payload).encode(),
                    qos=1,
                )
            logger.debug(f"[MQTT] Published → {topic}: {payload}")
            return True
        except Exception as e:
            logger.error(f"[MQTT] Publish error: {e}")
            return False

    async def subscribe(self, topic: str, handler: Callable) -> None:
        """Registra handler para um tópico."""
        if topic not in self._handlers:
            self._handlers[topic] = []
        self._handlers[topic].append(handler)

    async def _listen(self) -> None:
        """Loop de escuta de mensagens MQTT."""
        if not self._client:
            return
        try:
            async with self._client as client:
                await client.subscribe("axis/#")
                async for message in client.messages:
                    topic = str(message.topic)
                    try:
                        payload = json.loads(message.payload.decode())
                    except Exception:
                        payload = {"raw": message.payload.decode()}

                    # Dispara handlers registrados
                    for registered_topic, handlers in self._handlers.items():
                        if self._topic_matches(registered_topic, topic):
                            for handler in handlers:
                                try:
                                    await handler(topic, payload)
                                except Exception as e:
                                    logger.error(f"[MQTT] Handler error: {e}")
        except Exception as e:
            logger.error(f"[MQTT] Listen error: {e}")

    @staticmethod
    def _topic_matches(pattern: str, topic: str) -> bool:
        """Verifica se tópico bate com padrão (suporte a +/* wildcards)."""
        pattern_parts = pattern.split("/")
        topic_parts = topic.split("/")
        if len(pattern_parts) != len(topic_parts) and "#" not in pattern_parts:
            return False
        for p, t in zip(pattern_parts, topic_parts):
            if p == "#":
                return True
            if p != "+" and p != t:
                return False
        return True

    @property
    def is_connected(self) -> bool:
        return self._connected
