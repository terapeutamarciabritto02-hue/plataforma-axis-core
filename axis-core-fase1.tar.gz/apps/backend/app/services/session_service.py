from uuid import UUID
from datetime import datetime, timezone
from supabase import AsyncClient

from app.schemas.session import (
    SessionCreate, SessionUpdate, SessionResponse,
    SessionListResponse, SessionStartResponse,
)
from app.core.exceptions import NotFoundError, ForbiddenError, TenantIsolationError
from app.dependencies import CurrentUser


class SessionService:
    def __init__(self, supabase: AsyncClient, user: CurrentUser):
        self.db = supabase
        self.user = user

    async def create(self, data: SessionCreate) -> SessionResponse:
        if not self.user.tenant_id:
            raise ForbiddenError("No tenant associated with account")

        row = {
            "tenant_id":    str(self.user.tenant_id),
            "therapist_id": await self._get_therapist_id(),
            "client_id":    str(data.client_id),
            "table_id":     str(data.table_id) if data.table_id else None,
            "protocol_id":  str(data.protocol_id) if data.protocol_id else None,
            "scheduled_at": data.scheduled_at.isoformat(),
            "notes":        data.notes,
            "status":       "scheduled",
        }

        result = await self.db.table("sessions").insert(row).execute()
        return SessionResponse(**result.data[0])

    async def list(
        self,
        client_id: UUID | None = None,
        status: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> SessionListResponse:
        query = self.db.table("sessions").select("*", count="exact")

        if self.user.role.value != "admin":
            therapist_id = await self._get_therapist_id()
            query = query.eq("therapist_id", therapist_id)
        
        if client_id:
            query = query.eq("client_id", str(client_id))
        if status:
            query = query.eq("status", status)

        offset = (page - 1) * page_size
        query = query.range(offset, offset + page_size - 1)
        query = query.order("scheduled_at", desc=True)

        result = await query.execute()
        sessions = [SessionResponse(**s) for s in result.data]

        return SessionListResponse(
            sessions=sessions,
            total=result.count or 0,
            page=page,
            page_size=page_size,
        )

    async def get_by_id(self, session_id: UUID) -> SessionResponse | None:
        result = await self.db.table("sessions") \
            .select("*") \
            .eq("id", str(session_id)) \
            .maybeSingle() \
            .execute()

        if not result.data:
            return None

        await self._assert_access(result.data)
        return SessionResponse(**result.data)

    async def update(self, session_id: UUID, data: SessionUpdate) -> SessionResponse:
        existing = await self.db.table("sessions") \
            .select("*") \
            .eq("id", str(session_id)) \
            .single() \
            .execute()

        if not existing.data:
            raise NotFoundError("Session", str(session_id))

        await self._assert_access(existing.data)

        updates = data.model_dump(exclude_none=True)
        if "scheduled_at" in updates:
            updates["scheduled_at"] = updates["scheduled_at"].isoformat()

        result = await self.db.table("sessions") \
            .update(updates) \
            .eq("id", str(session_id)) \
            .execute()

        return SessionResponse(**result.data[0])

    async def start(self, session_id: UUID) -> SessionStartResponse:
        existing = await self.db.table("sessions") \
            .select("*") \
            .eq("id", str(session_id)) \
            .single() \
            .execute()

        if not existing.data:
            raise NotFoundError("Session", str(session_id))

        await self._assert_access(existing.data)

        now = datetime.now(timezone.utc)

        await self.db.table("sessions").update({
            "status":     "in_progress",
            "started_at": now.isoformat(),
        }).eq("id", str(session_id)).execute()

        ws_url = f"/ws/session/{session_id}"

        return SessionStartResponse(
            session_id=session_id,
            status="in_progress",
            started_at=now,
            websocket_url=ws_url,
        )

    async def end(self, session_id: UUID) -> SessionResponse:
        existing = await self.db.table("sessions") \
            .select("*") \
            .eq("id", str(session_id)) \
            .single() \
            .execute()

        if not existing.data:
            raise NotFoundError("Session", str(session_id))

        await self._assert_access(existing.data)

        now = datetime.now(timezone.utc)
        started_at = existing.data.get("started_at")
        duration_min = None

        if started_at:
            start_dt = datetime.fromisoformat(started_at)
            duration_min = int((now - start_dt).total_seconds() / 60)

        result = await self.db.table("sessions").update({
            "status":       "completed",
            "ended_at":     now.isoformat(),
            "duration_min": duration_min,
        }).eq("id", str(session_id)).execute()

        return SessionResponse(**result.data[0])

    async def cancel(self, session_id: UUID) -> None:
        existing = await self.db.table("sessions") \
            .select("id, tenant_id") \
            .eq("id", str(session_id)) \
            .single() \
            .execute()

        if not existing.data:
            raise NotFoundError("Session", str(session_id))

        await self.db.table("sessions") \
            .update({"status": "cancelled"}) \
            .eq("id", str(session_id)) \
            .execute()

    # ── Helpers ──────────────────────────────────────────────

    async def _get_therapist_id(self) -> str:
        result = await self.db.table("therapists") \
            .select("id") \
            .eq("profile_id", self.user.id) \
            .single() \
            .execute()
        if not result.data:
            raise ForbiddenError("Therapist profile not found")
        return result.data["id"]

    async def _assert_access(self, session: dict) -> None:
        if self.user.role.value == "admin":
            return
        if self.user.tenant_id and str(session.get("tenant_id")) != str(self.user.tenant_id):
            raise TenantIsolationError()
