import json
import asyncio
from typing import Dict, Set
from fastapi import WebSocket
from datetime import datetime, timezone


class ConnectionManager:
    """
    Gerencia conexões WebSocket por sessão.
    Cada session_id pode ter múltiplos clientes conectados (terapeuta + cliente).
    """

    def __init__(self):
        self._sessions: Dict[str, Set[WebSocket]] = {}

    async def connect(self, session_id: str, websocket: WebSocket) -> None:
        await websocket.accept()
        if session_id not in self._sessions:
            self._sessions[session_id] = set()
        self._sessions[session_id].add(websocket)

    def disconnect(self, session_id: str, websocket: WebSocket) -> None:
        if session_id in self._sessions:
            self._sessions[session_id].discard(websocket)
            if not self._sessions[session_id]:
                del self._sessions[session_id]

    async def broadcast(self, session_id: str, event_type: str, payload: dict) -> None:
        """Envia evento para todos os clientes de uma sessão."""
        if session_id not in self._sessions:
            return

        message = json.dumps({
            "type":       event_type,
            "session_id": session_id,
            "timestamp":  datetime.now(timezone.utc).isoformat(),
            "payload":    payload,
        })

        dead: set[WebSocket] = set()
        tasks = []

        for ws in self._sessions[session_id]:
            tasks.append(self._safe_send(ws, message, dead))

        await asyncio.gather(*tasks)

        for ws in dead:
            self._sessions[session_id].discard(ws)

    async def send_to(self, websocket: WebSocket, event_type: str, payload: dict) -> None:
        """Envia evento para um único WebSocket."""
        message = json.dumps({
            "type":      event_type,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "payload":   payload,
        })
        await websocket.send_text(message)

    async def _safe_send(
        self, ws: WebSocket, message: str, dead: set[WebSocket]
    ) -> None:
        try:
            await ws.send_text(message)
        except Exception:
            dead.add(ws)

    def active_sessions(self) -> list[str]:
        return list(self._sessions.keys())

    def count(self, session_id: str) -> int:
        return len(self._sessions.get(session_id, set()))

    def total_connections(self) -> int:
        return sum(len(v) for v in self._sessions.values())
