import json
from fastapi import WebSocket, WebSocketDisconnect, APIRouter
from app.websocket.manager import ConnectionManager

router = APIRouter()
manager = ConnectionManager()


@router.websocket("/ws/session/{session_id}")
async def session_websocket(websocket: WebSocket, session_id: str):
    """
    WebSocket de tempo real para uma sessão ativa.

    Eventos emitidos pelo servidor:
    - session.started      → sessão iniciada
    - session.ended        → sessão encerrada
    - telemetry.update     → dado telemétrico novo
    - engine.command_ack   → confirmação de comando de mesa
    - engine.status        → status de dispositivo físico
    - error                → erro de processamento

    Eventos aceitos do cliente:
    - ping                 → keepalive
    - telemetry.manual     → inserção manual de dado
    """
    await manager.connect(session_id, websocket)

    # Notifica conexão
    await manager.send_to(websocket, "connected", {
        "session_id":   session_id,
        "message":      "Connected to session stream",
        "connections":  manager.count(session_id),
    })

    try:
        while True:
            raw = await websocket.receive_text()

            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                await manager.send_to(websocket, "error", {"detail": "Invalid JSON"})
                continue

            event_type = msg.get("type", "unknown")

            if event_type == "ping":
                await manager.send_to(websocket, "pong", {})

            elif event_type == "telemetry.manual":
                # Re-broadcast para todos na sessão
                await manager.broadcast(session_id, "telemetry.update", msg.get("payload", {}))

            else:
                await manager.send_to(websocket, "error", {
                    "detail": f"Unknown event type: {event_type}"
                })

    except WebSocketDisconnect:
        manager.disconnect(session_id, websocket)
        await manager.broadcast(session_id, "peer.disconnected", {
            "connections": manager.count(session_id),
        })
