from pydantic_settings import BaseSettings, SettingsConfigDict
from functools import lru_cache


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
    )

    # App
    ENVIRONMENT: str = "development"
    BACKEND_SECRET_KEY: str = "change-me-min-32-characters-long!!"
    ALLOWED_ORIGINS: list[str] = ["http://localhost:3000"]
    ALLOWED_HOSTS: list[str] = ["localhost"]

    # Supabase
    SUPABASE_URL: str
    SUPABASE_SERVICE_ROLE_KEY: str

    # MQTT
    MQTT_BROKER_URL: str = "localhost"
    MQTT_PORT: int = 1883
    MQTT_USERNAME: str = "axis_core"
    MQTT_PASSWORD: str = ""

    # Redis
    REDIS_URL: str = "redis://localhost:6379"

    @property
    def is_production(self) -> bool:
        return self.ENVIRONMENT == "production"


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
