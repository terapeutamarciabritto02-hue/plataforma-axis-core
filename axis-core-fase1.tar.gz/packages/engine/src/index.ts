import type { AxisTableDefinition, TableType } from '@axis/core'

// ── Registry ──────────────────────────────────────────────────

class AxisTableRegistry {
  private static _instance: AxisTableRegistry
  private tables: Map<string, AxisTableDefinition> = new Map()

  static getInstance(): AxisTableRegistry {
    if (!AxisTableRegistry._instance) {
      AxisTableRegistry._instance = new AxisTableRegistry()
    }
    return AxisTableRegistry._instance
  }

  register(def: AxisTableDefinition): void {
    if (this.tables.has(def.slug)) {
      throw new Error(`[AxisEngine] Table "${def.slug}" already registered`)
    }
    this.tables.set(def.slug, def)
    console.info(`[AxisEngine] Registered: ${def.name} (${def.slug})`)
  }

  get(slug: string): AxisTableDefinition | undefined {
    return this.tables.get(slug)
  }

  getByType(type: TableType): AxisTableDefinition[] {
    return [...this.tables.values()].filter(t => t.type === type)
  }

  list(): AxisTableDefinition[] {
    return [...this.tables.values()]
  }

  has(slug: string): boolean {
    return this.tables.has(slug)
  }

  clear(): void {
    this.tables.clear()
  }
}

export const registry = AxisTableRegistry.getInstance()

// ── Loader ────────────────────────────────────────────────────

const REQUIRED_FIELDS = ['id', 'slug', 'name', 'type', 'version', 'parameters', 'capabilities']

export class AxisTableLoader {
  static loadFromJSON(raw: unknown): AxisTableDefinition {
    if (!raw || typeof raw !== 'object') {
      throw new Error('[AxisEngine] Invalid table definition: must be an object')
    }

    const def = raw as Record<string, unknown>

    for (const field of REQUIRED_FIELDS) {
      if (!(field in def)) {
        throw new Error(`[AxisEngine] Invalid table definition: missing field "${field}"`)
      }
    }

    registry.register(def as AxisTableDefinition)
    return def as AxisTableDefinition
  }

  static loadMany(defs: unknown[]): AxisTableDefinition[] {
    return defs.map(def => AxisTableLoader.loadFromJSON(def))
  }

  static async loadDefaults(): Promise<void> {
    const modules = await Promise.all([
      import('./tables/hado-quantum.json'),
      import('./tables/multidimensional.json'),
      import('./tables/radionica.json'),
      import('./tables/chakras.json'),
      import('./tables/frequencies.json'),
    ])
    modules.forEach(mod => AxisTableLoader.loadFromJSON(mod.default))
    console.info(`[AxisEngine] Loaded ${modules.length} default tables`)
  }
}
