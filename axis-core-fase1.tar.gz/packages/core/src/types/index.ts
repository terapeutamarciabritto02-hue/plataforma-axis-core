export type UserRole = 'admin' | 'therapist' | 'client' | 'student'

export type SessionStatus = 'scheduled' | 'in_progress' | 'completed' | 'cancelled'

export type TableType =
  | 'hado_quantum'
  | 'multidimensional'
  | 'radionica'
  | 'chakras'
  | 'frequencies'

export type DeviceStatus = 'online' | 'offline' | 'error'

export type ReportStatus = 'draft' | 'generated' | 'signed' | 'delivered'

// ── Users ─────────────────────────────────────────────────────

export interface Profile {
  id:          string
  role:        UserRole
  full_name:   string
  avatar_url:  string | null
  phone:       string | null
  is_active:   boolean
  created_at:  string
  updated_at:  string
}

export interface Tenant {
  id:         string
  owner_id:   string
  name:       string
  slug:       string
  plan:       string
  settings:   Record<string, unknown>
  is_active:  boolean
  created_at: string
}

export interface Therapist {
  id:              string
  profile_id:      string
  tenant_id:       string
  bio:             string | null
  specialties:     string[]
  registration_id: string | null
  profile?:        Profile
  created_at:      string
}

export interface Client {
  id:           string
  profile_id:   string | null
  tenant_id:    string
  therapist_id: string
  full_name:    string
  email:        string | null
  phone:        string | null
  birth_date:   string | null
  notes:        string | null
  metadata:     Record<string, unknown>
  is_active:    boolean
  created_at:   string
}

// ── Sessions ──────────────────────────────────────────────────

export interface Session {
  id:           string
  tenant_id:    string
  therapist_id: string
  client_id:    string
  table_id:     string | null
  protocol_id:  string | null
  status:       SessionStatus
  scheduled_at: string
  started_at:   string | null
  ended_at:     string | null
  duration_min: number | null
  notes:        string | null
  metadata:     Record<string, unknown>
  created_at:   string
  updated_at:   string
}

// ── Engine ────────────────────────────────────────────────────

export interface TableParameter {
  id:          string
  label:       string
  type:        'number' | 'select' | 'boolean' | 'text'
  unit?:       string
  min?:        number
  max?:        number
  default:     unknown
  options?:    string[]
  description?: string
}

export interface TableStep {
  id:               string
  order:            number
  label:            string
  duration_seconds?: number
  parameters:       Record<string, unknown>
}

export interface AxisTableDefinition {
  id:           string
  slug:         string
  name:         string
  type:         TableType
  version:      string
  description:  string
  author:       string
  parameters:   TableParameter[]
  default_steps: TableStep[]
  mqtt_topics?: {
    start:  string
    stop:   string
    status: string
    data:   string
  }
  capabilities: {
    realtime:        boolean
    physical_device: boolean
    biometry_input:  boolean
    multi_user:      boolean
  }
}

// ── Telemetry ─────────────────────────────────────────────────

export interface TelemetryLog {
  id:         string
  session_id: string
  tenant_id:  string
  timestamp:  string
  source:     'websocket' | 'mqtt' | 'manual'
  payload:    Record<string, unknown>
  processed:  boolean
}

export interface BiometryReading {
  id:            string
  session_id:    string
  timestamp:     string
  metric_type:   'hrv_rmssd' | 'bpm' | 'stress_index'
  value:         number
  unit:          string
  device_source: string | null
}

// ── WebSocket Events ──────────────────────────────────────────

export interface WSEvent {
  type:       string
  session_id?: string
  timestamp:  string
  payload:    Record<string, unknown>
}

// ── API Responses ─────────────────────────────────────────────

export interface PaginatedResponse<T> {
  data:      T[]
  total:     number
  page:      number
  page_size: number
}

export interface APIErrorResponse {
  detail: string
  status: number
}
