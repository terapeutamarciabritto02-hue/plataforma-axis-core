-- ============================================================
-- AXIS CORE™ — Schema PostgreSQL v1.0.0
-- Execute no Supabase: Dashboard → SQL Editor → Run
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ── ENUMS ────────────────────────────────────────────────────
DO $$ BEGIN
  CREATE TYPE user_role AS ENUM ('admin','therapist','client','student');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE session_status AS ENUM ('scheduled','in_progress','completed','cancelled');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE table_type AS ENUM ('hado_quantum','multidimensional','radionica','chakras','frequencies');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE report_status AS ENUM ('draft','generated','signed','delivered');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE device_status AS ENUM ('online','offline','error');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- ── PROFILES ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.profiles (
  id          UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  role        user_role NOT NULL DEFAULT 'client',
  full_name   TEXT NOT NULL,
  avatar_url  TEXT,
  phone       TEXT,
  is_active   BOOLEAN NOT NULL DEFAULT TRUE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_profiles_role   ON public.profiles(role);
CREATE INDEX IF NOT EXISTS idx_profiles_active ON public.profiles(is_active);

-- ── TENANTS ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.tenants (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  owner_id   UUID NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
  name       TEXT NOT NULL,
  slug       TEXT NOT NULL,
  plan       TEXT NOT NULL DEFAULT 'starter',
  settings   JSONB NOT NULL DEFAULT '{}',
  is_active  BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_tenants_slug  ON public.tenants(slug);
CREATE INDEX IF NOT EXISTS idx_tenants_owner        ON public.tenants(owner_id);

-- ── THERAPISTS ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.therapists (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  profile_id      UUID NOT NULL UNIQUE REFERENCES public.profiles(id) ON DELETE CASCADE,
  tenant_id       UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  bio             TEXT,
  specialties     TEXT[] DEFAULT '{}',
  registration_id TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_therapists_tenant  ON public.therapists(tenant_id);
CREATE INDEX IF NOT EXISTS idx_therapists_profile ON public.therapists(profile_id);

-- ── CLIENTS ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.clients (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  profile_id   UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  tenant_id    UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  therapist_id UUID NOT NULL REFERENCES public.therapists(id) ON DELETE RESTRICT,
  full_name    TEXT NOT NULL,
  email        TEXT,
  phone        TEXT,
  birth_date   DATE,
  notes        TEXT,
  metadata     JSONB NOT NULL DEFAULT '{}',
  is_active    BOOLEAN NOT NULL DEFAULT TRUE,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_clients_tenant    ON public.clients(tenant_id);
CREATE INDEX IF NOT EXISTS idx_clients_therapist ON public.clients(therapist_id);
CREATE INDEX IF NOT EXISTS idx_clients_profile   ON public.clients(profile_id);

-- ── STUDENTS ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.students (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  profile_id      UUID NOT NULL UNIQUE REFERENCES public.profiles(id) ON DELETE CASCADE,
  tenant_id       UUID REFERENCES public.tenants(id) ON DELETE SET NULL,
  enrollment_date DATE NOT NULL DEFAULT CURRENT_DATE,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_students_tenant ON public.students(tenant_id);

-- ── AXIS_TABLES ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.axis_tables (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id     UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  name          TEXT NOT NULL,
  slug          TEXT NOT NULL,
  table_type    table_type NOT NULL,
  config        JSONB NOT NULL DEFAULT '{}',
  device_id     TEXT,
  device_status device_status NOT NULL DEFAULT 'offline',
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(tenant_id, slug)
);
CREATE INDEX IF NOT EXISTS idx_axis_tables_tenant ON public.axis_tables(tenant_id);
CREATE INDEX IF NOT EXISTS idx_axis_tables_type   ON public.axis_tables(table_type);

-- ── AXIS_PROTOCOLS ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.axis_protocols (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id    UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  therapist_id UUID NOT NULL REFERENCES public.therapists(id) ON DELETE CASCADE,
  name         TEXT NOT NULL,
  description  TEXT,
  table_type   table_type NOT NULL,
  steps        JSONB NOT NULL DEFAULT '[]',
  duration_min INTEGER NOT NULL DEFAULT 30,
  is_public    BOOLEAN NOT NULL DEFAULT FALSE,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_protocols_tenant    ON public.axis_protocols(tenant_id);
CREATE INDEX IF NOT EXISTS idx_protocols_therapist ON public.axis_protocols(therapist_id);

-- ── SESSIONS ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.sessions (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id    UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  therapist_id UUID NOT NULL REFERENCES public.therapists(id) ON DELETE RESTRICT,
  client_id    UUID NOT NULL REFERENCES public.clients(id) ON DELETE RESTRICT,
  table_id     UUID REFERENCES public.axis_tables(id) ON DELETE SET NULL,
  protocol_id  UUID REFERENCES public.axis_protocols(id) ON DELETE SET NULL,
  status       session_status NOT NULL DEFAULT 'scheduled',
  scheduled_at TIMESTAMPTZ NOT NULL,
  started_at   TIMESTAMPTZ,
  ended_at     TIMESTAMPTZ,
  duration_min INTEGER,
  notes        TEXT,
  metadata     JSONB NOT NULL DEFAULT '{}',
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_sessions_tenant    ON public.sessions(tenant_id);
CREATE INDEX IF NOT EXISTS idx_sessions_therapist ON public.sessions(therapist_id);
CREATE INDEX IF NOT EXISTS idx_sessions_client    ON public.sessions(client_id);
CREATE INDEX IF NOT EXISTS idx_sessions_status    ON public.sessions(status);
CREATE INDEX IF NOT EXISTS idx_sessions_scheduled ON public.sessions(scheduled_at);

-- ── REPORTS ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.reports (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id    UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  session_id   UUID NOT NULL REFERENCES public.sessions(id) ON DELETE CASCADE,
  client_id    UUID NOT NULL REFERENCES public.clients(id) ON DELETE RESTRICT,
  therapist_id UUID NOT NULL REFERENCES public.therapists(id) ON DELETE RESTRICT,
  status       report_status NOT NULL DEFAULT 'draft',
  content      JSONB NOT NULL DEFAULT '{}',
  pdf_url      TEXT,
  signed_at    TIMESTAMPTZ,
  delivered_at TIMESTAMPTZ,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_reports_tenant    ON public.reports(tenant_id);
CREATE INDEX IF NOT EXISTS idx_reports_session   ON public.reports(session_id);
CREATE INDEX IF NOT EXISTS idx_reports_client    ON public.reports(client_id);

-- ── TELEMETRY_LOGS ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.telemetry_logs (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  session_id UUID NOT NULL REFERENCES public.sessions(id) ON DELETE CASCADE,
  tenant_id  UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  timestamp  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  source     TEXT NOT NULL,
  payload    JSONB NOT NULL DEFAULT '{}',
  processed  BOOLEAN NOT NULL DEFAULT FALSE
);
CREATE INDEX IF NOT EXISTS idx_telemetry_session   ON public.telemetry_logs(session_id);
CREATE INDEX IF NOT EXISTS idx_telemetry_tenant    ON public.telemetry_logs(tenant_id);
CREATE INDEX IF NOT EXISTS idx_telemetry_timestamp ON public.telemetry_logs(timestamp DESC);

-- ── BIOMETRY_LOGS ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.biometry_logs (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  session_id    UUID NOT NULL REFERENCES public.sessions(id) ON DELETE CASCADE,
  tenant_id     UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  timestamp     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  metric_type   TEXT NOT NULL,
  value         NUMERIC NOT NULL,
  unit          TEXT NOT NULL,
  device_source TEXT,
  raw_data      JSONB DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_biometry_session   ON public.biometry_logs(session_id);
CREATE INDEX IF NOT EXISTS idx_biometry_metric    ON public.biometry_logs(metric_type);
CREATE INDEX IF NOT EXISTS idx_biometry_timestamp ON public.biometry_logs(timestamp DESC);

-- ── COURSES ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.courses (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id    UUID REFERENCES public.tenants(id) ON DELETE SET NULL,
  author_id    UUID NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
  title        TEXT NOT NULL,
  description  TEXT,
  thumbnail_url TEXT,
  is_published BOOLEAN NOT NULL DEFAULT FALSE,
  is_public    BOOLEAN NOT NULL DEFAULT FALSE,
  price_brl    NUMERIC(10,2) DEFAULT 0,
  metadata     JSONB NOT NULL DEFAULT '{}',
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_courses_tenant    ON public.courses(tenant_id);
CREATE INDEX IF NOT EXISTS idx_courses_published ON public.courses(is_published);

-- ── COURSE_MODULES ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.course_modules (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  course_id    UUID NOT NULL REFERENCES public.courses(id) ON DELETE CASCADE,
  title        TEXT NOT NULL,
  description  TEXT,
  order_index  INTEGER NOT NULL DEFAULT 0,
  content_type TEXT NOT NULL,
  content_url  TEXT,
  duration_min INTEGER,
  is_free      BOOLEAN NOT NULL DEFAULT FALSE,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_modules_course ON public.course_modules(course_id, order_index);

-- ── NOTIFICATIONS ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.notifications (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  recipient_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  tenant_id    UUID REFERENCES public.tenants(id) ON DELETE CASCADE,
  type         TEXT NOT NULL,
  title        TEXT NOT NULL,
  body         TEXT,
  data         JSONB DEFAULT '{}',
  is_read      BOOLEAN NOT NULL DEFAULT FALSE,
  read_at      TIMESTAMPTZ,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_notifications_recipient ON public.notifications(recipient_id);
CREATE INDEX IF NOT EXISTS idx_notifications_unread    ON public.notifications(recipient_id, is_read) WHERE is_read = FALSE;

-- ── AUDIT_LOGS ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  actor_id      UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  tenant_id     UUID REFERENCES public.tenants(id) ON DELETE SET NULL,
  action        TEXT NOT NULL,
  resource_type TEXT NOT NULL,
  resource_id   UUID,
  old_data      JSONB,
  new_data      JSONB,
  ip_address    INET,
  user_agent    TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_audit_tenant   ON public.audit_logs(tenant_id);
CREATE INDEX IF NOT EXISTS idx_audit_action   ON public.audit_logs(action);
CREATE INDEX IF NOT EXISTS idx_audit_resource ON public.audit_logs(resource_type, resource_id);
CREATE INDEX IF NOT EXISTS idx_audit_created  ON public.audit_logs(created_at DESC);

-- ── TRIGGERS ─────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

DO $$ DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['profiles','tenants','therapists','clients','sessions','reports','courses','axis_tables','axis_protocols']
  LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS trg_%s_updated_at ON public.%s', t, t);
    EXECUTE format('CREATE TRIGGER trg_%s_updated_at BEFORE UPDATE ON public.%s FOR EACH ROW EXECUTE FUNCTION update_updated_at()', t, t);
  END LOOP;
END $$;

-- Auto-criar profile no signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'Novo Usuário'),
    COALESCE((NEW.raw_user_meta_data->>'role')::user_role, 'client')
  ) ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ── RLS ──────────────────────────────────────────────────────
DO $$ DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'profiles','tenants','therapists','clients','students',
    'sessions','reports','telemetry_logs','biometry_logs',
    'axis_tables','axis_protocols','courses','course_modules',
    'notifications','audit_logs'
  ]
  LOOP
    EXECUTE format('ALTER TABLE public.%s ENABLE ROW LEVEL SECURITY', t);
  END LOOP;
END $$;

-- Helper functions
CREATE OR REPLACE FUNCTION auth.user_role()
RETURNS user_role AS $$
  SELECT role FROM public.profiles WHERE id = auth.uid();
$$ LANGUAGE SQL SECURITY DEFINER STABLE;

CREATE OR REPLACE FUNCTION auth.user_tenant_id()
RETURNS UUID AS $$
  SELECT t.id FROM public.tenants t
  JOIN public.therapists th ON th.tenant_id = t.id
  WHERE th.profile_id = auth.uid() LIMIT 1;
$$ LANGUAGE SQL SECURITY DEFINER STABLE;

-- Policies
DROP POLICY IF EXISTS "profiles_select" ON public.profiles;
CREATE POLICY "profiles_select" ON public.profiles FOR SELECT
  USING (id = auth.uid() OR auth.user_role() = 'admin');

DROP POLICY IF EXISTS "profiles_update" ON public.profiles;
CREATE POLICY "profiles_update" ON public.profiles FOR UPDATE
  USING (id = auth.uid());

DROP POLICY IF EXISTS "sessions_tenant" ON public.sessions;
CREATE POLICY "sessions_tenant" ON public.sessions FOR ALL
  USING (
    tenant_id = auth.user_tenant_id()
    OR auth.user_role() = 'admin'
    OR client_id IN (SELECT id FROM public.clients WHERE profile_id = auth.uid())
  );

DROP POLICY IF EXISTS "clients_tenant" ON public.clients;
CREATE POLICY "clients_tenant" ON public.clients FOR ALL
  USING (
    tenant_id = auth.user_tenant_id()
    OR auth.user_role() = 'admin'
    OR profile_id = auth.uid()
  );

DROP POLICY IF EXISTS "reports_scope" ON public.reports;
CREATE POLICY "reports_scope" ON public.reports FOR SELECT
  USING (
    tenant_id = auth.user_tenant_id()
    OR auth.user_role() = 'admin'
    OR client_id IN (SELECT id FROM public.clients WHERE profile_id = auth.uid())
  );

DROP POLICY IF EXISTS "telemetry_tenant" ON public.telemetry_logs;
CREATE POLICY "telemetry_tenant" ON public.telemetry_logs FOR ALL
  USING (tenant_id = auth.user_tenant_id() OR auth.user_role() = 'admin');

DROP POLICY IF EXISTS "notifications_own" ON public.notifications;
CREATE POLICY "notifications_own" ON public.notifications FOR ALL
  USING (recipient_id = auth.uid() OR auth.user_role() = 'admin');

DROP POLICY IF EXISTS "audit_admin" ON public.audit_logs;
CREATE POLICY "audit_admin" ON public.audit_logs FOR SELECT
  USING (auth.user_role() = 'admin');
